# CI-CD-using-Docker
This repository will run a java application in a tomcat container using  Jenkins and Docker


# Youtube Link

https://www.youtube.com/watch?v=B1sjiq1wD_Y&feature=youtu.be

# Blog Link
https://devops4solutions.com/ci-cd-using-jenkins-and-docker-2/
